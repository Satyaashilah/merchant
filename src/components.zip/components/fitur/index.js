// import { StyleSheet, Text, TouchableOpacity, Image, View } from 'react-native'
// import React from 'react'

// const Fitur = () => {
//     return (
//         <View style={{ flexDirection: 'column' }}>
//             <View style={{ flexDirection: 'row' }}>
//                 <TouchableOpacity>
//                     <View style={style.kotak3}>
//                         <View>
//                             <Image source={require('../assets/images/order.png')}
//                                 style={style.fiturHome}
//                                 resizeMode="cover" />
//                         </View>
//                     </View>
//                     <Text style={style.fiturHomeTxt}>Pesanan</Text>
//                 </TouchableOpacity>

//                 <TouchableOpacity>
//                     <View style={style.kotak3}>
//                         <View>
//                             <Image source={require('../assets/images/menu.png')}
//                                 style={style.fiturHome}
//                                 resizeMode="cover" />
//                         </View>
//                     </View>
//                     <Text style={style.fiturHomeTxt}>Menu</Text>
//                 </TouchableOpacity>

//                 <TouchableOpacity>
//                     <View style={style.kotak3}>
//                         <View>
//                             <Image source={require('../assets/images/groceries.png')}
//                                 style={style.fiturHome}
//                                 resizeMode="cover" />
//                         </View>
//                     </View>
//                     <Text style={style.fiturHomeTxt}>Grosir</Text>
//                 </TouchableOpacity>

//                 <TouchableOpacity>
//                     <View style={style.kotak3}>
//                         <View>
//                             <Image source={require('../assets/images/coupon.png')}
//                                 style={style.fiturHome}
//                                 resizeMode="cover" />
//                         </View>
//                     </View>
//                     <Text style={style.fiturHomeTxt}>Diskon</Text>
//                 </TouchableOpacity>

//             </View>


//             <View style={{ flexDirection: 'row' }}>
//                 <TouchableOpacity>
//                     <View style={style.kotak3}>
//                         <View>
//                             <Image source={require('../assets/images/finance.png')}
//                                 style={style.fiturHome}
//                                 resizeMode="cover" />
//                         </View>
//                     </View>
//                     <Text style={style.fiturHomeTxt}>Keuangan</Text>
//                 </TouchableOpacity>

//                 <TouchableOpacity>
//                     <View style={style.kotak3}>
//                         <View>
//                             <Image source={require('../assets/images/group.png')}
//                                 style={style.fiturHome}
//                                 resizeMode="cover" />
//                         </View>
//                     </View>
//                     <Text style={style.fiturHomeTxt}>Karyawan</Text>
//                 </TouchableOpacity>
//             </View>
//         </View>
//     )
// }

// export default Fitur;

// const style = StyleSheet.create({
//     kotak3: {
//         marginHorizontal: '5.5%',
//         height: 60,
//         width: 60,
//         backgroundColor: '#ffffff',
//         borderColor: '#DEDEDE',
//         borderRadius: 8,
//     },

//     fiturHome: {
//         width: 30,
//         height: 30,
//         marginLeft: 'auto',
//         marginRight: 'auto',
//         marginTop: '25%'
//     },
//     fiturHomeTxt: {
//         marginHorizontal: '5.5%',
//         height: 60,
//         width: 60,
//         fontWeight: 'bold',
//         fontSize: 12,
//         textAlign: 'center',
//         color: '#4C4C4C'
//     }
// });